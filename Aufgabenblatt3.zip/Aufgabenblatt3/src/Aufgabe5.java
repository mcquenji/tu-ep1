/*
    Aufgabe 4) Quadrate => Rekursiv
*/

import codedraw.*;

import java.awt.*;

public class Aufgabe5 {

    private static void drawRecursiveSquares(CodeDraw myDrawObj, int x, int y, int s) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Methode
    }

    public static void main(String[] args) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}



